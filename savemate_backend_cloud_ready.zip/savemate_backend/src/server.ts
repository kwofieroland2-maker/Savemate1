import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { PrismaClient, TransactionStatus, TransactionType } from "@prisma/client";
import crypto from "crypto";

const prisma = new PrismaClient();
const app = express();
app.use((req,res,next)=>{
  if(req.path === "/api/payment/webhook") return express.raw({type:"application/json", limit:"256kb"})(req,res,next);
  return express.json({limit:"256kb"})(req,res,next);
});

const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "";
if (!JWT_SECRET) {
  console.error("JWT_SECRET is required");
  process.exit(1);
}
const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY || "";

function token(userId:string){ return jwt.sign({userId}, JWT_SECRET, {expiresIn:"7d"}); }
function auth(req:any,res:any,next:any){
  try {
    const h=req.headers.authorization || "";
    const t=h.startsWith("Bearer ")?h.slice(7):"";
    req.user=jwt.verify(t,JWT_SECRET) as {userId:string};
    next();
  } catch { res.status(401).json({error:"Unauthorized"}); }
}
const money=z.number().positive().finite();

app.get("/health",(_,res)=>res.json({ok:true,service:"savemate-backend"}));

app.post("/api/auth/register", async(req,res)=>{
  try{
    const body=z.object({name:z.string().min(2),phone:z.string().min(8),password:z.string().min(6)}).parse(req.body);
    const exists=await prisma.user.findUnique({where:{phone:body.phone}});
    if(exists) return res.status(409).json({error:"Phone already registered"});
    const passwordHash=await bcrypt.hash(body.password,12);
    const user=await prisma.user.create({data:{
      name:body.name,phone:body.phone,passwordHash,
      account:{create:{currency:"GHS"}}
    }});
    res.status(201).json({token:token(user.id),user:{id:user.id,name:user.name,phone:user.phone}});
  }catch(e){res.status(400).json({error:"Invalid registration data"});}
});

app.post("/api/auth/login", async(req,res)=>{
  const body=z.object({phone:z.string(),password:z.string()}).parse(req.body);
  const user=await prisma.user.findUnique({where:{phone:body.phone}});
  if(!user || !(await bcrypt.compare(body.password,user.passwordHash))) return res.status(401).json({error:"Invalid credentials"});
  res.json({token:token(user.id),user:{id:user.id,name:user.name,phone:user.phone}});
});

app.get("/api/account",auth,async(req:any,res)=>{
  const account=await prisma.savingsAccount.findUnique({where:{userId:req.user.userId}});
  res.json(account);
});

app.get("/api/goals",auth,async(req:any,res)=>{
  res.json(await prisma.goal.findMany({where:{userId:req.user.userId},orderBy:{createdAt:"desc"}}));
});

app.post("/api/goals",auth,async(req:any,res)=>{
  const b=z.object({name:z.string().min(2),target:money,deadline:z.string().datetime().optional()}).parse(req.body);
  const goal=await prisma.goal.create({data:{userId:req.user.userId,name:b.name,target:b.target,deadline:b.deadline?new Date(b.deadline):undefined}});
  res.status(201).json(goal);
});

app.get("/api/transactions",auth,async(req:any,res)=>{
  res.json(await prisma.transaction.findMany({where:{userId:req.user.userId},orderBy:{createdAt:"desc"},take:100}));
});

app.post("/api/deposits",auth,async(req:any,res)=>{
  const b=z.object({amount:money,goalId:z.string(),email:z.string().email(),phone:z.string().min(8),provider:z.enum(["mtn","atl","vod"])}).parse(req.body);
  const goal=await prisma.goal.findFirst({where:{id:b.goalId,userId:req.user.userId}});
  if(!goal) return res.status(404).json({error:"Goal not found"});
  const reference="DEP-"+crypto.randomUUID();
  const payment=await prisma.paymentAttempt.create({data:{userId:req.user.userId,goalId:b.goalId,reference,provider:"paystack",amount:b.amount}});
  if(!PAYSTACK_SECRET_KEY) return res.status(202).json({reference,paymentId:payment.id,status:"PENDING",message:"Set PAYSTACK_SECRET_KEY on the server to enable payments."});
  try{
    const r=await fetch("https://api.paystack.co/charge",{method:"POST",headers:{Authorization:`Bearer ${PAYSTACK_SECRET_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({email:b.email,amount:Math.round(b.amount*100),currency:"GHS",reference,mobile_money:{phone:b.phone,provider:b.provider}})});
    const d:any=await r.json();
    if(!r.ok||!d.status){await prisma.paymentAttempt.update({where:{id:payment.id},data:{status:"FAILED"}});return res.status(502).json({error:"Payment provider rejected the request",details:d.message});}
    res.status(202).json({reference,paymentId:payment.id,status:d.data?.status||"PENDING",displayText:d.data?.display_text||"Approve the payment on your phone."});
  }catch{await prisma.paymentAttempt.update({where:{id:payment.id},data:{status:"FAILED"}});res.status(502).json({error:"Payment provider unavailable"});}
});

app.post("/api/withdrawals",auth,async(req:any,res)=>{
  const b=z.object({amount:money}).parse(req.body);
  const account=await prisma.savingsAccount.findUnique({where:{userId:req.user.userId}});
  if(!account || Number(account.balance)<b.amount) return res.status(400).json({error:"Insufficient available balance"});
  // Production implementation should create a pending withdrawal and require provider confirmation.
  res.status(202).json({status:"PENDING",message:"Withdrawal request created for provider processing"});
});

app.post("/api/payment/webhook",async(req,res)=>{
  const signature=String(req.headers["x-paystack-signature"]||"");
  const secret=PAYSTACK_SECRET_KEY;
  const raw=Buffer.isBuffer(req.body)?req.body:Buffer.from(JSON.stringify(req.body||{}));
  if(!secret) return res.status(503).json({error:"Payment webhook is not configured"});
  const expected=crypto.createHmac("sha512",secret).update(raw).digest("hex");
  if (!signature || signature.length !== expected.length) return res.status(401).json({error:"Invalid webhook signature"});
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return res.status(401).json({error:"Invalid webhook signature"});
  let event:any;
  try { event=JSON.parse(raw.toString("utf8")); } catch { return res.status(400).json({error:"Invalid JSON webhook"}); }
  const data=event.data||{};
  if(event.event!=="charge.success") return res.json({ok:true});
  const payment=await prisma.paymentAttempt.findUnique({where:{reference:data.reference}});
  if(!payment) return res.status(404).json({error:"Payment not found"});
  if(payment.status==="SUCCESS") return res.json({ok:true});
  if(Number(data.amount)/100!==Number(payment.amount)||data.currency!=="GHS") return res.status(400).json({error:"Payment amount/currency mismatch"});
  await prisma.$transaction(async tx=>{
    await tx.paymentAttempt.update({where:{id:payment.id},data:{status:"SUCCESS",providerRef:String(data.id)}});
    await tx.transaction.create({data:{userId:payment.userId,goalId:payment.goalId,type:TransactionType.DEPOSIT,status:TransactionStatus.COMPLETED,amount:payment.amount,currency:"GHS",reference:payment.reference,providerRef:String(data.id)}});
    await tx.savingsAccount.update({where:{userId:payment.userId},data:{balance:{increment:payment.amount}}});
    if(payment.goalId) await tx.goal.update({where:{id:payment.goalId},data:{saved:{increment:payment.amount}}});
  });
  res.json({ok:true});
});

app.listen(PORT,()=>console.log(`SaveMate API listening on :${PORT}`));