# Paystack Ghana MoMo

The first payment adapter uses Paystack Ghana Mobile Money.

Provider codes:
- `mtn` — MTN
- `atl` — Airtel/Tigo
- `vod` — Telecel

Flow:
1. App creates a deposit.
2. Backend creates a Paystack charge in GHS.
3. Customer authorizes the mobile-money prompt.
4. Paystack sends `charge.success` to the webhook.
5. Backend verifies the webhook, amount and currency.
6. A single database transaction marks the payment successful, records the ledger transaction, credits the account and credits the selected goal.

Keep `PAYSTACK_SECRET_KEY` server-side only.

Paystack currently does not support recurring Ghana MoMo charges, so automatic savings should initially be reminder-based/manual authorization.
