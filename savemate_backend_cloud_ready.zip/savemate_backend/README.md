# SaveMate Ghana Backend Starter

A production-oriented starter API for the SaveMate Ghana savings app.

## Stack
- Node.js + TypeScript
- Express
- Prisma ORM
- PostgreSQL
- JWT authentication
- Zod validation

## Run
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env` and set `DATABASE_URL` and `JWT_SECRET`.
3. `npm install`
4. `npx prisma generate`
5. `npx prisma migrate dev --name init`
6. `npm run dev`

The payment provider is intentionally abstracted. Real-money transactions must only be credited after a verified provider webhook.

## API
POST `/api/auth/register`
POST `/api/auth/login`
GET `/api/account`
GET `/api/goals`
POST `/api/goals`
POST `/api/deposits`
GET `/api/transactions`
POST `/api/withdrawals`
POST `/api/payment/webhook`
