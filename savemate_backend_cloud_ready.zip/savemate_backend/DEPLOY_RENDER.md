# SaveMate Ghana — Render deployment

1. Create a PostgreSQL database in your hosting provider.
2. Create a Web Service from this repository using the included Dockerfile/render.yaml.
3. Set `DATABASE_URL`, `JWT_SECRET`, and `PAYSTACK_SECRET_KEY` as private environment variables.
4. Deploy. The container runs `prisma migrate deploy` before starting the API.
5. Confirm `GET /health` returns `{"ok":true,...}`.
6. Configure Paystack's webhook URL as `https://YOUR-DOMAIN/api/payment/webhook`.
7. Use Paystack test credentials first. Do not enable live money until webhook, duplicate-payment, amount/currency, and failed-payment tests pass.

Never commit `.env` or payment secrets to source control.
