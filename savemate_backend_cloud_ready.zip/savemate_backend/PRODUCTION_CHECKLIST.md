# SaveMate Ghana — deployment checklist

## Before deployment
- [ ] Replace all example secrets.
- [ ] Use a managed PostgreSQL database with backups.
- [ ] Configure HTTPS/TLS.
- [ ] Set a strong JWT secret.
- [ ] Add Paystack test keys first.
- [ ] Configure the Paystack webhook URL to `/api/payment/webhook`.
- [ ] Verify webhook signatures.
- [ ] Test successful, failed, duplicate, and mismatched-amount payments.
- [ ] Add rate limiting and request logging.
- [ ] Add OTP/phone verification before production onboarding.
- [ ] Add a proper withdrawal approval/provider flow.
- [ ] Configure monitoring and alerts.

## Payment go-live gates
A live payment key should NOT be enabled until:
1. A successful test payment credits exactly once.
2. A repeated webhook does not double-credit.
3. A failed payment does not credit the account.
4. A wrong amount/currency is rejected.
5. Provider references are stored.
6. Ledger and balance remain consistent after failures/retries.

## Run locally
`docker compose up --build`

Health check:
`GET http://localhost:3000/health`

Do not put secret keys in the mobile application.
