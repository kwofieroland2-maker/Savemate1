-- CreateEnum
CREATE TYPE "TransactionType" AS ENUM ('DEPOSIT', 'WITHDRAWAL', 'REVERSAL', 'ADJUSTMENT');
CREATE TYPE "TransactionStatus" AS ENUM ('PENDING', 'COMPLETED', 'FAILED', 'REVERSED');
CREATE TYPE "GoalStatus" AS ENUM ('ACTIVE', 'COMPLETED', 'PAUSED');
CREATE TYPE "PaymentStatus" AS ENUM ('INITIATED', 'PENDING', 'SUCCESS', 'FAILED', 'REVERSED');

CREATE TABLE "User" (
  "id" TEXT NOT NULL, "name" TEXT NOT NULL, "phone" TEXT NOT NULL, "passwordHash" TEXT NOT NULL, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "User_phone_key" ON "User"("phone");

CREATE TABLE "SavingsAccount" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "balance" DECIMAL(18,2) NOT NULL DEFAULT 0, "currency" TEXT NOT NULL DEFAULT 'GHS', "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "SavingsAccount_pkey" PRIMARY KEY ("id"), CONSTRAINT "SavingsAccount_userId_key" UNIQUE ("userId"),
  CONSTRAINT "SavingsAccount_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE TABLE "Goal" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "name" TEXT NOT NULL, "target" DECIMAL(18,2) NOT NULL, "saved" DECIMAL(18,2) NOT NULL DEFAULT 0, "deadline" TIMESTAMP(3), "status" "GoalStatus" NOT NULL DEFAULT 'ACTIVE', "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Goal_pkey" PRIMARY KEY ("id"), CONSTRAINT "Goal_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE TABLE "Transaction" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "goalId" TEXT, "type" "TransactionType" NOT NULL, "status" "TransactionStatus" NOT NULL DEFAULT 'PENDING', "amount" DECIMAL(18,2) NOT NULL, "currency" TEXT NOT NULL DEFAULT 'GHS', "reference" TEXT NOT NULL, "providerRef" TEXT, "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Transaction_pkey" PRIMARY KEY ("id"), CONSTRAINT "Transaction_reference_key" UNIQUE ("reference"),
  CONSTRAINT "Transaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "Transaction_goalId_fkey" FOREIGN KEY ("goalId") REFERENCES "Goal"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE "PaymentAttempt" (
  "id" TEXT NOT NULL, "userId" TEXT NOT NULL, "reference" TEXT NOT NULL, "provider" TEXT NOT NULL, "providerRef" TEXT, "goalId" TEXT, "amount" DECIMAL(18,2) NOT NULL, "status" "PaymentStatus" NOT NULL DEFAULT 'INITIATED', "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PaymentAttempt_pkey" PRIMARY KEY ("id"), CONSTRAINT "PaymentAttempt_reference_key" UNIQUE ("reference"),
  CONSTRAINT "PaymentAttempt_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "PaymentAttempt_goalId_fkey" FOREIGN KEY ("goalId") REFERENCES "Goal"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
