import crypto from "node:crypto";

const BASE = (process.env.API_URL || "http://localhost:3000").replace(/\/$/, "");
const SECRET = process.env.PAYSTACK_SECRET_KEY || "development-test-paystack-secret";
const unique = `smoke-${Date.now()}-${Math.random().toString(16).slice(2)}`;

async function req(path, options={}) {
  const r = await fetch(BASE + path, { ...options, headers: { "content-type":"application/json", ...(options.headers||{}) }});
  const text = await r.text();
  let body; try { body = JSON.parse(text); } catch { body = text; }
  if (!r.ok) throw new Error(`${options.method||"GET"} ${path} -> ${r.status}: ${JSON.stringify(body)}`);
  return body;
}

const registered = await req("/api/auth/register", {method:"POST", body:JSON.stringify({name:"SaveMate Smoke Test", phone:`024${String(Date.now()).slice(-7)}`, password:"TestPass123!"})});
const auth = { Authorization:`Bearer ${registered.token}` };
const goal = await req("/api/goals", {method:"POST", headers:auth, body:JSON.stringify({name:"Smoke Goal", target:100})});
const deposit = await req("/api/deposits", {method:"POST", headers:auth, body:JSON.stringify({amount:25, goalId:goal.id, email:`${unique}@example.com`, phone:"0240000000", provider:"mtn"})});

const event = {event:"charge.success", data:{reference:deposit.reference, id:`test-${Date.now()}`, status:"success", amount:2500, currency:"GHS"}};
const raw = JSON.stringify(event);
const signature = crypto.createHmac("sha512", SECRET).update(raw).digest("hex");

async function webhook(body, sig=signature){
  const r = await fetch(BASE+"/api/payment/webhook", {method:"POST", headers:{"content-type":"application/json","x-paystack-signature":sig}, body});
  const text=await r.text();
  if(!r.ok) throw new Error(`webhook -> ${r.status}: ${text}`);
  return JSON.parse(text);
}

await webhook(raw);
await webhook(raw); // must be idempotent

const account = await req("/api/account", {headers:auth});
const goals = await req("/api/goals", {headers:auth});
const txs = await req("/api/transactions", {headers:auth});

if (Number(account.balance) !== 25) throw new Error(`Expected account balance 25, got ${account.balance}`);
if (Number(goals.find(g=>g.id===goal.id).saved) !== 25) throw new Error("Goal was not credited exactly once");
const matching = txs.filter(t=>t.reference===deposit.reference);
if (matching.length !== 1) throw new Error(`Expected exactly one ledger transaction, got ${matching.length}`);

console.log("PASS: registration, goal creation, deposit initiation, signed webhook, duplicate webhook, and exact-once crediting.");
